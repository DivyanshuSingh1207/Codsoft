CODSOFT

Internship Projects

📄 Task 1 - "Landing Page"

This project aims to create a captivating and user-friendly landing page using HTML and CSS. The landing page serves as the gateway to our website, making it crucial to leave a lasting impression on visitors. Here's what you need to know about the task:

📁 Task 2 - "Portfolio Website"

In this task, you will build your personal portfolio website to showcase your skills, projects, and achievements as a web developer. Your portfolio is a reflection of your professional identity, so make it stand out with these features:

🧮 Task 3 - "Calculator Website"

This task focuses on building a fully functional calculator website using HTML, CSS, and JavaScript. The calculator should be capable of performing basic arithmetic operations and more complex calculations.
